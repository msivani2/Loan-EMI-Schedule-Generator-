import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402
from emi import build_schedule, due_date, emi  # noqa: E402
from loan_csv import parse_loan_csv  # noqa: E402

HDR = "loan_id,borrower,principal,annual_rate,tenure_months,start_date,resets\n"


class EngineTests(unittest.TestCase):
    def test_matches_home_page_sample(self):
        rows = build_schedule({"principal": 500000, "rate": 10.5, "tenure": 24, "start": "2026-01-05", "resets": {}})
        self.assertEqual(rows[0]["interest"], 4375.0)
        self.assertEqual(rows[0]["principal"], 18813.02)
        self.assertEqual(rows[0]["closing"], 481186.98)
        self.assertEqual(rows[1]["interest"], 4210.39)
        self.assertEqual(rows[2]["closing"], 443065.66)

    def test_closes_at_zero(self):
        for resets in ({}, {12: 10.0, 24: 10.75}, {2: 0, 3: 30}):
            rows = build_schedule({"principal": 1200000, "rate": 9.25, "tenure": 36, "start": "2026-02-10", "resets": resets})
            self.assertEqual(rows[-1]["closing"], 0)
        self.assertEqual(emi(1200, 0, 12), 100)

    def test_due_dates_clamp(self):
        self.assertEqual(due_date("2026-01-31", 1), "2026-02-28")
        self.assertEqual(due_date("2028-01-31", 1), "2028-02-29")
        self.assertEqual(due_date("2026-11-15", 3), "2027-02-15")

    def test_csv(self):
        loans, errs = parse_loan_csv(HDR + 'A1,"Rao, K",1000,10,12,2026-01-01,6:11')
        self.assertEqual(errs, [])
        self.assertEqual(loans[0]["borrower"], "Rao, K")
        self.assertEqual(loans[0]["resets"], {6: 11.0})
        _, errs = parse_loan_csv(HDR + "A1,X,-5,10,12,2026-02-30,13:5")
        self.assertGreaterEqual(len(errs), 3)
        _, errs = parse_loan_csv(HDR + "A1,X,100,10,12.5,2026-01-01,\nA1,Y,100,10,12,2026-01-01,")
        self.assertTrue(any("tenure" in e for e in errs) and any("duplicate" in e for e in errs))


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app(os.path.join(self.tmp.name, "t.db"))
        self.c = self.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def login(self, email, pw):
        c = self.app.test_client()
        r = c.post("/api/login", json={"email": email, "pw": pw})
        self.assertEqual(r.status_code, 200)
        return c, r

    def test_full_flow(self):
        c = self.c
        self.assertEqual(c.get("/api/me").status_code, 401)
        self.assertEqual(c.post("/api/signup", json={"name": "A", "email": "a@x.com", "pw": "short"}).status_code, 400)
        self.assertEqual(c.post("/api/signup", json={"name": "Asha", "email": "Asha@X.com", "pw": "password123"}).status_code, 201)
        self.assertEqual(c.post("/api/signup", json={"name": "Asha", "email": "asha@x.com", "pw": "password123"}).status_code, 409)
        self.assertEqual(c.post("/api/login", json={"email": "asha@x.com", "pw": "wrongpass1"}).status_code, 401)
        self.assertEqual(c.post("/api/login", data="x", content_type="text/plain").status_code, 415)

        a, r = self.login("asha@x.com", "password123")
        self.assertIn("HttpOnly", r.headers["Set-Cookie"])
        self.assertEqual(a.get("/api/me").get_json()["name"], "Asha")

        import sqlite3
        conn = sqlite3.connect(self.app.config["DB_FILE"])
        stored = conn.execute("SELECT pw_hash FROM users").fetchone()[0]
        conn.close()
        self.assertNotIn("password123", stored)
        self.assertTrue(stored.startswith("scrypt:"))

        csv = HDR + "LN1,Ravi,500000,10.5,24,2026-01-05,\nLN2,Anitha,1200000,9.25,36,2026-02-10,12:10.0|24:10.75"
        imp = a.post("/api/loans/import", json={"csv": csv})
        self.assertEqual(imp.status_code, 200)
        self.assertEqual(len(imp.get_json()["loans"]), 2)
        bad = a.post("/api/loans/import", json={"csv": "bad"})
        self.assertEqual(bad.status_code, 422)
        self.assertIn("details", bad.get_json())

        s = a.get("/api/loans/LN1/schedule").get_json()
        self.assertEqual(len(s["rows"]), 24)
        self.assertEqual(s["rows"][-1]["closing"], 0)
        self.assertEqual(a.get("/api/loans/LN2/schedule").get_json()["summary"]["resetCount"], 2)

        r = a.post("/api/loans/LN1/resets", json={"month": "12", "rate": "11.25"}).get_json()  # strings, as the form sends
        self.assertEqual(r["summary"]["resetCount"], 1)
        self.assertTrue(r["rows"][11]["isReset"])
        self.assertEqual(a.post("/api/loans/LN1/resets", json={"month": 1, "rate": 11}).status_code, 400)
        self.assertEqual(a.post("/api/loans/LN1/resets", json={"month": 5, "rate": ""}).status_code, 400)
        self.assertEqual(a.get("/api/loans/LN1/schedule").get_json()["summary"]["resetCount"], 1)  # persisted
        self.assertEqual(a.delete("/api/loans/LN1/resets/12").get_json()["summary"]["resetCount"], 0)

        # re-import upserts
        a.post("/api/loans/import", json={"csv": HDR + "LN1,Ravi K,600000,10.5,24,2026-01-05,"})
        self.assertEqual(a.get("/api/loans/LN1/schedule").get_json()["loan"]["principal"], 600000)

        # isolation
        c.post("/api/signup", json={"name": "Bala", "email": "bala@x.com", "pw": "password456"})
        b, _ = self.login("bala@x.com", "password456")
        self.assertEqual(b.get("/api/loans/LN1/schedule").status_code, 404)
        self.assertEqual(b.get("/api/loans").get_json()["loans"], [])
        self.assertEqual(b.delete("/api/loans/LN1").status_code, 404)

        self.assertEqual(self.app.test_client().get("/api/loans").status_code, 401)
        self.assertEqual(a.delete("/api/loans/LN2").status_code, 200)
        a.post("/api/logout")
        self.assertEqual(a.get("/api/me").status_code, 401)

    def test_static_and_security(self):
        c = self.c
        self.assertEqual(c.get("/").status_code, 200)
        self.assertEqual(c.get("/generator.html").status_code, 200)
        self.assertEqual(c.get("/app.js").status_code, 200)
        for p in ("/../app.py", "/..%2fapp.py", "/%2e%2e/app.py"):
            self.assertNotEqual(c.get(p).status_code, 200, p)
        self.assertEqual(c.get("/api/nope").status_code, 404)

    def test_login_throttle(self):
        self.c.post("/api/signup", json={"name": "T", "email": "t@x.com", "pw": "password123"})
        codes = [self.c.post("/api/login", json={"email": "t@x.com", "pw": "bad-password"}).status_code for _ in range(11)]
        self.assertEqual(codes[:10], [401] * 10)
        self.assertEqual(codes[10], 429)
        from app import clear_failures
        clear_failures("127.0.0.1|t@x.com")


if __name__ == "__main__":
    unittest.main()
